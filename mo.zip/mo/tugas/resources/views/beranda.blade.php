@extends('template')

@section('judul_halaman', 'Halaman Beranda')


@section('konten')

        <p>Ini adalah halaman konten</p>
        <p>Selamat Datang !</p>

@endsection