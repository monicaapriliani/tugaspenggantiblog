@extends('template')

@section('judul_halaman', 'Halaman Diary')


@section('konten') 

@endsection

        <p>Hallo, disini saya akan menceritakan tentang semua pengalaman saya sampai detik ini saya berada di semester 5 ya. 
           waktu semester 1 saya mengikuti unit kegiatan mahasiswa jurnalistik, yang dimana pada saat LDK saya ragu mau ikut lanjut
           atau tidak seleksinya dikarenakan mager, tetapi temen kos dan shinta membujuk saya supaya tetap ikutan dan akhirnya oke saya lanjutkan,
           dengan keadaan tidak niat mengikuti LDK di Gong Silegi eh gak taunya saya malah jadi mbak LDK hehe sangat lucu yaa tapi memang seru
           waktu itu jadi saya semangat.
           untuk semester 2 saya lupa bagaimana ceritanya, intinya sama seperti semester 1 yang berjalan apa adanya. 
           semester 3 saatnya corona, yang dimana perkuliahan semua online dan saya pulang ke lampung. disisi lain saya mengikuti HIMATEKNO yaitu himpunan mahasiswa teknologi informasi dan disini saya banyak mendapat pengetahuan, pengalaman, dan lain hal. 
           hima menurut saya organisasi yang bagus untuk mengenal prodi kita sendiri.
           semester 4 masih corona dan kuliahnya sistem daring dan luring, saya tetap menikmati dan harus menikmati.
           semester 5 baru berjalan setengah tahun kurang dan saya merasakan vibes dari semester 5 memang luarbiasa, tapi ada hal yang membuat pengalaman saya bertambah yaitu 
           saya menjadi ketua panitia makrab mahasiswa baru tahun 2021 menurut saya itu hal yang luar biasa. </p>
        <p>sekian dulu ya ceritanya, sampai ketemu lain waktu, sehat-sehat semuanya</p>