@extends('master')

@section('judul_halaman', 'Halaman Tentang')


@section('konten')

        <p>Ini adalah halaman tentang</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>

@endsection