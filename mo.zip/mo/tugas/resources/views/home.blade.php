@extends('master')

@section('judul_halaman', 'Halaman Home')


@section('konten')

        <p>Ini adalah halaman konten</p>
        <p>Selamat Datang !</p>

@endsection