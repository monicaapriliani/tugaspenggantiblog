@extends('master')

@section('judul_halaman', 'Halaman Kontak')


@section('konten')

        <p>Ini adalah halaman Kontak</p>
        
        <table border="1">
            <tr>
                <td>Email</td>
                <td>:</td>
                <td>dinda@gmail.com</td>
            </tr>
            <tr>
                <td>Hp</td>
                <td>:</td>
                <td>0896-0676-7404</td>
            </tr>
        </table>
@endsection