@extends('template')

@section('judul_halaman', 'Halaman Profil')

@section('konten')@endsection

<html lang="en">
<head>
    <title>Profil</title>
    <style>
                table {
                font-family: Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
                }

                table td, th {
                border: 1px solid #ddd;
                padding: 8px;
                }

                table tr:nth-child(even){background-color: #f2f2f2;}
                table tr:hover {background-color: #ddd;}
                table th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #5F9EA0;
                color: white;
                }  
                
    </style></head>
<body>
    <table>
        <tr>
            <th>NIM</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Alamat</th>
            <th>No Whatsapp</th>
            <th>Hobi</th>
            <th>Skill</th>
            <th>Impian</th>
            <th>Langkah</th>
        </tr>
        @foreach($data as $dt)
        <tr>
            <td>{{$dt['NIM']}}</td>
            <td>{{$dt['Nama']}}</td>
            <td>{{$dt['Kelas']}}</td>
            <td>{{$dt['Alamat']}}</td>
            <td>{{$dt['No Whatsapp']}}</td>
            <td>{{$dt['Hobi']}}</td>
            <td>{{$dt['Skill']}}</td>
            <td>{{$dt['Impian']}}</td>
            <td>{{$dt['Langkah']}}</td>
        </tr>@endforeach
    </table>
</body></html>