

<?php $__env->startSection('judul_halaman', 'Halaman Profil'); ?>

<?php $__env->startSection('konten'); ?><?php $__env->stopSection(); ?>

<html lang="en">
<head>
    <title>Profil</title>
    <style>
                table {
                font-family: Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
                }

                table td, th {
                border: 1px solid #ddd;
                padding: 8px;
                }

                table tr:nth-child(even){background-color: #f2f2f2;}
                table tr:hover {background-color: #ddd;}
                table th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #5F9EA0;
                color: white;
                }  
                
    </style></head>
<body>
    <table>
        <tr>
            <th>NIM</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Alamat</th>
            <th>No Whatsapp</th>
            <th>Hobi</th>
            <th>Skill</th>
            <th>Impian</th>
            <th>Langkah</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($dt['NIM']); ?></td>
            <td><?php echo e($dt['Nama']); ?></td>
            <td><?php echo e($dt['Kelas']); ?></td>
            <td><?php echo e($dt['Alamat']); ?></td>
            <td><?php echo e($dt['No Whatsapp']); ?></td>
            <td><?php echo e($dt['Hobi']); ?></td>
            <td><?php echo e($dt['Skill']); ?></td>
            <td><?php echo e($dt['Impian']); ?></td>
            <td><?php echo e($dt['Langkah']); ?></td>
        </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body></html>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mo\tugas\resources\views/profil.blade.php ENDPATH**/ ?>