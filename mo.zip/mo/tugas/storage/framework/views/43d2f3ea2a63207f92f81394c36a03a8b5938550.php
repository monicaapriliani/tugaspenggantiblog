<html lang="en">
<html>
<head>
    <title>Selamat Datang Di Website</title>
</head>
<body>
    <header>
        <h2>Blog Personal</h2>
        <nav>
            <a href="/blog">HOME</a>
            
            <a href="/blog/tentang">TENTANG</a>

            <a href="/blog/kontak">KONTAK</a>
        </nav>
</header>
<hr/>
<br/>
<br/>

<h3><?php echo $__env->yieldContent('judul_halaman'); ?></h3>

<?php echo $__env->yieldContent('konten'); ?>


<br/>
<br/>
<hr/>
<footer>
    <p>&copy; <h5> Mahasiswa Universitas Muhammadiyah Purworejo
        Program Studi Teknologi Informasi</h5>. 2021 </p>
</footer>
</body>
</html><?php /**PATH D:\mo\tugas\resources\views/master.blade.php ENDPATH**/ ?>