<!DOCTYPE html>
<html lang="en">
<head>
<title>CSS Template</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
  background-color:#8FBC8F;
}

header {
  background-color: #5F9EA0;
  padding: 30px;
  text-align: center;
  font-size: 35px;
  color: white;
}

article {
  
  padding: 20px;
  width: 70%;
  background-color: #f1f1f1;
  
}

section::after {
  content: "";
  display: table;
  clear: both;
}

footer {
  background-color: #5F9EA0;
  padding: 10px;
  text-align: center;
  color: white;
}

@media  {
    article {
    width: auto;
    height: auto;
  }
}
</style>
</head>
<body>

<h2>Selamat Datang Teman Onlineku</h2>
<p>Selamat membaca tentang pribadi saya, semoga semuanya pada suka dan selalu support saya</p>
<p>Dipersilahkan untuk kepo tentang saya :)</p>

<header>
  <h2>Monica Disini</h2>
</header>

<section>
    <article>
        <h1><a href="/halo">HOME</a></h1>
        <p>halo semuanya, semoga pada sehat-sehat semua ya</p>
    </article>

    <article>
        <h1><a href="/halo/profil">PROFIL</a></h1>
        <p> Silahkan Klik menu profil untuk melihat saya lebih dekat </p>
    </article>

    <article>
        <h1><a href="/halo/diary">DIARY</a></h1>
        <p> Pada menu diary, saya menuliskan semua pengalaman saya selama berkuliah di Universitas Muhammadiyah Purworejo loh, bagi yang kepo silahkan 
            diklik aja ya menu diarynya, terimasih</p>
    </article>
</section>

<h3><?php echo $__env->yieldContent('judul_halaman'); ?></h3>

<?php echo $__env->yieldContent('konten'); ?>

<footer>
   <a href="contact.html">Kontak</a>
   <a href="about.html">Mengenai</a>
   <a href="copyright.html">Copyright</a>
   <a href="privacy.html">Privacy</a>
    Copyright© <a href="?">hayoo</a> - 2020
   </footer>
</body>
</html>

<?php /**PATH D:\mo\tugas\resources\views/template.blade.php ENDPATH**/ ?>