

<?php $__env->startSection('judul_halaman', 'Halaman Kontak'); ?>


<?php $__env->startSection('konten'); ?>

        <p>Ini adalah halaman Kontak</p>
        
        <table border="1">
            <tr>
                <td>Email</td>
                <td>:</td>
                <td>dinda@gmail.com</td>
            </tr>
            <tr>
                <td>Hp</td>
                <td>:</td>
                <td>0896-0676-7404</td>
            </tr>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mo\tugas\resources\views/kontak.blade.php ENDPATH**/ ?>