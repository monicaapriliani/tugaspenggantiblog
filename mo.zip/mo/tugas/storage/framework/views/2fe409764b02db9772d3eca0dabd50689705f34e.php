

<?php $__env->startSection('judul_halaman', 'Halaman Home'); ?>


<?php $__env->startSection('konten'); ?>

        <p>Ini adalah halaman konten</p>
        <p>Selamat Datang !</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mo\tugas\resources\views/home.blade.php ENDPATH**/ ?>