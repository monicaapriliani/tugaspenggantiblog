

<?php $__env->startSection('judul_halaman', 'Halaman Tentang'); ?>


<?php $__env->startSection('konten'); ?>

        <p>Ini adalah halaman tentang</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mo\tugas\resources\views/tentang.blade.php ENDPATH**/ ?>