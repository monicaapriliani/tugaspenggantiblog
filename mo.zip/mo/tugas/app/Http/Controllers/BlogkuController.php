<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogkuController extends Controller
{
    public function beranda(){
        return view('beranda');
    }

    public function profil(){
            $data = array(
                array("NIM"=>"192520041", "Nama"=>"Monica Apriliani", "Kelas"=>"5B", "Alamat"=>"Lampung", "No Whatsapp"=>"081377894181", "Hobi"=>"jalan",
                "Skill"=>"Definisi semua bisa tapi gak jago", "Impian"=>"Product Manager", "Langkah"=>"Mendalami Peran sebagai PM(Belajar, Berlatih, Evaluasi"),
            );
            return view ('profil', ['data'=>$data]);  
    }

    public function diary(){
        return view('diary');
    }
}
